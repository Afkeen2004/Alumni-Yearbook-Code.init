from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Connect to MySQL
mycon = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Keerthana2004",
    database="CHUMMA"
)

if mycon.is_connected():
    print("Successfully connected to MySQL")

mycur = mycon.cursor()

# Create table if it doesn't exist
mycur.execute("""
    CREATE TABLE IF NOT EXISTS extra (
        name VARCHAR(20),
        age INT,
        subject VARCHAR(20)
    )
""")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Retrieve form data
        name = request.form['data1']
        age = request.form['data2']
        subject = request.form['data3']

        # Example: Insert data into MySQL
        mycur.execute("INSERT INTO extra (name, age, subject) VALUES (%s, %s, %s)", (name, age, subject))
        mycon.commit()

        # Redirect to success page
        return redirect(url_for('success'))

@app.route('/success')
def success():
    return 'Data submitted successfully'

if __name__ == '__main__':
    app.run(debug=True)
