from flask import Flask, request, render_template, abort
import mysql.connector as ms

mycon = ms.connect(host="localhost", user="root", passwd="Keerthana2004", database="alumni")
if mycon.is_connected():
    print("Successfully connected to mysql")
mycur = mycon.cursor()
print("hello1")

app = Flask(__name__)

@app.route('/', methods=["POST","GET"])
def gfg():
    print("Inside gfg function")
    return render_template("first.html")

@app.route('/login.html', methods=["GET", "POST"])
def login():
    if request.method == "POST" or request.method == "GET": 
        username = request.form.get("email")
        password = request.form.get("password")
        
        query = "SELECT * FROM data WHERE email LIKE %s"
        mycur.execute(query, (f"%{username}%",))

        user = mycur.fetchone()
        
        if user:
            user_password = user[9]
            print(user_password)
            
            if password == user_password:  
                # Here you can render a template displaying user details
                return render_template('username.html', user=user)
        
        # If user is not found or password does not match
        print("Invalid username or password")
        return render_template('login.html', error="Invalid username or password")

    print("Rendering login.html")
    return render_template('login.html')

@app.route('/profile.html', methods=["GET", "POST"])
def profile():
    if request.method == "POST" or request.method == "GET":
        nam = request.form.get("name")
        ema = request.form.get("email")
        pho = request.form.get("phone")
        occ = request.form.get("occupation")
        com = request.form.get("company")
        loc = request.form.get("location")
        ach = request.form.get("achievements")
        gra = request.form.get("graduation-year")
        pwd = request.form.get("password")
        cpwd = request.form.get("confirm password")
        
        if nam and pwd==cpwd:  # Check if 'name' field is not empty
            query = "INSERT INTO data (name, email, phoneno, occupation, company, location, achievements, gradyear, password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            mycur.execute(query, (nam, ema, pho, occ, com, loc, ach, gra, pwd))
            # Commit the changes to the database
            mycon.commit()
            # Render the profile page again
            return render_template('first.html')
        else:
            return render_template('profile.html', error="Name cannot be empty")

    print("Rendering profile.html")
    return render_template('profile.html')


@app.route('/search.html', methods=["GET", "POST"])
def search():
    if request.method == "POST" or request.method == "GET":
        search_query = request.form.get("intext")
        query = "SELECT * FROM data WHERE gradyear LIKE %s"
        mycur.execute(query, (f"%{search_query}%",))

        # Fetch all matching rows
        users = mycur.fetchall()
        if users:
            return render_template('uname.html', users=users)  # Pass users to the template

        # If no matching rows found, print search_query
        print(search_query)

        return render_template("search.html")
    # If it's a GET request or the search form is not submitted, render the search page
    return render_template("search.html")

@app.route('/search.html.', methods=["POST","GET"])
def cancel():
    if request.method == "POST" or request.method == "GET":
        return render_template("second.html")
    return render_template("second.html")

@app.route('/notfound')
def not_found():
    print("Page not found")
    abort(404)

if __name__ == '__main__':
    app.run(debug=True)